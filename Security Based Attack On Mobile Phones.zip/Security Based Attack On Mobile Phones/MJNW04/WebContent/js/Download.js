$(document).ready(
		function() {
			$('a').click(function(e) {
				
				
				var classvalue=$(this).attr('class');
				//alert(classvalue);
				
				e.preventDefault();
				if(classvalue=='download')
					{
					
					var elemt=$(this);
					var key=prompt("Enter the key value");
					
					if(key.length>0)
						{
					alert("keyt value");
					var dummy='cou='+elemt.attr('href');
					$.ajax({
						url:"keyverify.jsp?key="+key,
						data:dummy,
						cache:false,
						success:function(data)
						{
					//alert("sssssssssss"+data);
							$("#msg_Display").html(data).hide();
							var result=$("#msg").text();
							
							
							if(result=="sucess")
							{
								
							}
							else
								{
								/*alert("verify the key");
								var key =prompt("retry  the  Value")
								
								$("#filename").attr('value',elemt.attr('href'));
								$("#mahi").attr('action','delete');
								$("#mahi").submit();*/
								//alert("aa"+result);
								alert("success");
								$("#filename").attr('value',elemt.attr('href'));
								$("#iddown").attr('action','download');
								$("#iddown").submit();
								}
						}
						
						
					});
		}
					
					
				
					
					}
				else if(classvalue=='edit')
					{
					var elemt=$(this);
					var key=prompt("Enter the key value");
					
					if(key.length>0)
						{
						alert("enter correct key");
						var dummy='cou='+elemt.attr('href');
						$.ajax({
							url:"keyverify.jsp?key="+key,
							data:dummy,
							cache:false,
							success:function(data)
							{
						//alert("sssssssssss"+data);
								$("#msg_Display").html(data).hide();
								var result=$("#msg").text();
								
								//alert(result);
								if(result=='sucess')
								{
									alert("success");
									$("#Edit").attr('value',elemt.attr('href'));
									$("#idup").attr('action','edit');
									$("#idup").submit();
								}
								else
									{
									alert("verify the key");
									var key =prompt("retry  the  Value")
									
									$("#filename").attr('value',elemt.attr('href'));
									$("#mahi").attr('action','delete');
									$("#mahi").submit();
									}
							}
							
							
						});
						
						}
					
					}
			});
			
			
			
		}



);