package com.Servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connection.Dbconnection;




/**
 * Servlet implementation class Graph1
 */
@WebServlet("/Graph11")
public class Graph11 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Graph11() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("HIIIIIIIIIIIIIIIIIIII");
		Dbconnection admincon=new Dbconnection();
		ArrayList list=new ArrayList();
		ArrayList list2=new ArrayList();
		HttpSession session=request.getSession();
		
		list=admincon.getfilename();
		session.setAttribute("name1", list);
		
		list2=admincon.getfilesize();
		session.setAttribute("size1", list2);
		System.out.println("Lisst 111111"+list);
		System.out.println("Lisst 22222"+list2);
		RequestDispatcher dispatcher=request.getRequestDispatcher("performance.jsp");
		dispatcher.forward(request, response);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
