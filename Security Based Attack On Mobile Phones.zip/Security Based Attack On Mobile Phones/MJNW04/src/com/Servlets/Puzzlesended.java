package com.Servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;

import com.Bean.uploadBean;
import com.Connection.Dbconnection;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.oreilly.servlet.multipart.FilePart;
import com.oreilly.servlet.multipart.MultipartParser;
import com.oreilly.servlet.multipart.ParamPart;
import com.oreilly.servlet.multipart.Part;

/**
 * Servlet implementation class Puzzlesended
 */
@WebServlet("/Puzzlesended")
public class Puzzlesended extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Puzzlesended() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String saveFile="";
		   String text=null;
		   String Path="";
		   String dept="";
		   String filepath="";
		   File f=null;
		   response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();
	        int insert=0;
	        Set s =new HashSet();
		   try {

	            /****************/
	            FilePart filePart = null;
	            int maxFileSize = 100 * 1024 * 1024; // 100 MB;
	            MultipartParser mp = new MultipartParser(request, maxFileSize);
	            Part part;
	            HashMap<String, String> params = new HashMap<String, String>();
	            String fileName = null;
	            String category=null;
	            String msg=null;
	            int i=0;
	            ArrayList uploadlist=new ArrayList();
	            String uploadDir = getServletContext().getRealPath("");	           
				  
				   int a=uploadDir.indexOf('.');
				   String ff=uploadDir.substring(0,a);
				   System.out.println("ff: " + ff);
				   String uploadDir1=ff+"mjnw04/WebContent/puzzle_images/";
	            System.out.println("upload doccc  ::"+uploadDir1);

	            while ((part = mp.readNextPart()) != null)
	            {
	                  String name = part.getName();
	                  
	                  // If the part is parameter ... put the parameter in a hashmap with the key as the name of the request
	                  if (part.isParam())
	                  {
	                        // it's a parameter part
	                        ParamPart paramPart = (ParamPart) part;
	                        String value = paramPart.getStringValue();
	                        params.put(name, value);
	                        System.out.println("param list  >>"+params);
	                  }
	                  else if (part.isFile())
	                  { // case where the part of the reequest is a file it's a file part
	                        filePart = (FilePart) part;
	                        fileName = filePart.getFileName();
	                        System.out.println(uploadDir1+filePart.getFileName());
	                         Path=uploadDir1+filePart.getFileName();
	                         f = new File(uploadDir1,filePart.getFileName());
	                        System.out.println("f is ~~~ "+f);
	                        filepath=f.toString();
	                        System.out.println(",,,,,,,,,,,,,, "+filepath);
	                        double fileSize = filePart.writeTo(f);
	                  }
	                   s=(Set)params.entrySet();
	                  System.out.println("parames "+params);
	                  System.out.println("Value is ::"+params.values());
	                 
	                  
	                  System.out.println("Uploaded successfully !"+i);
	           }
	            Iterator ii=s.iterator();
          while(ii.hasNext())
          {
              Map.Entry m=(Map.Entry)ii.next();
               dept=m.getValue().toString();
              System.out.println("Valuuuuuuuuuuu "+dept);
              
              uploadlist.add(dept);
             
          }
          	String filename=f.getName();
          	String[] f_type=filename.split("\\.");
          	String f_n=f_type[0];
          	String f_t=f_type[1];
          	System.out.println("Type is ::"+f_t);
          	HttpSession hs=request.getSession();
          	String uid=(String)hs.getAttribute("uid");
          	String fname=(String)hs.getAttribute("fname");
          	System.out.println("user id "+uid);
          	System.out.println("filenameeee : "+fname);
	                Date d=new Date();
	                String date=d.toString();
	                uploadlist.add(uid);
	                uploadlist.add(fname);
	                uploadlist.add(f.getName());
	                uploadlist.add(filepath);
	                uploadlist.add(date);
	                uploadlist.add(f_t);
	                            
	                System.out.println("List to DB values ::"+uploadlist);
	                System.out.println("array value ::"+uploadlist.get(0));
	                Dbconnection db=new Dbconnection();
	                int i1=db.Upload_List(uploadlist);
	              
	        		if(i1>0)
	        		{
	        			
	  	                Class.forName("com.mysql.jdbc.Driver");
	  	                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mjnw04","root","root");
	  	                PreparedStatement ps=con.prepareStatement("update userrequsets set status='accept' where uid='"+uid+"'");
	  	                ps.executeUpdate();
	        			RequestDispatcher rd=request.getRequestDispatcher("puzzlesendtouser.jsp");
	        			rd.forward(request, response);
	        		}
	                System.out.println("insert upload list is >>>>>>>>>>>>> "+i1);
	        }
	            catch(Exception e)
	            {
	            e.printStackTrace();
	           }
	}
	

}
