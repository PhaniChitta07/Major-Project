package com.Connection;

	import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;



import com.Bean.uploadBean;




	public class Dbconnection {
		private static Connection con;

		public static Connection getConnection()
		{
			
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mjnw04","root", "root");
				
				System.out.println("Connection Loaded ");
				
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return con;
		}
		
		public int Upload_List(ArrayList uploadlist)
		{
			int i=1;
			String s="Not Solved";
			try
			{
				PreparedStatement st=getConnection().prepareStatement("insert into puzzleinfo values(?,?,?,?,?,?,?,?)");
				for(int j=0;j<uploadlist.size();j++)
				{
					st.setString(i, uploadlist.get(j).toString().trim());
					i++;
				}
				st.setString(8, s);
				st.executeUpdate();
				System.out.println("k in db insert");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return i;
		}
		
		public ArrayList getfilename()
		{
			ArrayList list=new ArrayList();
			try
			{
			Statement st=getConnection().createStatement();
			ResultSet rs=st.executeQuery("select gl from keywordsearch");
			String va="";
			while(rs.next())
			{
				
				va="GL="+rs.getString(1).toString().trim()+",GP";
				list.add(va);
			}
			}
			catch (Exception e) 
			{
				// TODO: handle exception
				e.printStackTrace();
			}
			return list;
		}
		public ArrayList getfilesize()
		{
			ArrayList list=new ArrayList();
			try
			{
				Statement st=getConnection().createStatement();
			ResultSet rs=st.executeQuery("select gp from keywordsearch");
			while(rs.next())
			{
				list.add(rs.getString(1).toString().trim());
			}
			}
			catch (Exception e) 
			{
				// TODO: handle exception
				e.printStackTrace();
			}
			return list;
		}
		
		public int fileUpload(uploadBean up) {
			// TODO Auto-generated method stub
			String s="1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			Random r=new Random();
			
			  char s1=s.charAt(r.nextInt(s.length()));
			  char s2=s.charAt(r.nextInt(s.length()));
			  char s3=s.charAt(r.nextInt(s.length()));
			  char s4=s.charAt(r.nextInt(s.length()));
			  char s5=s.charAt(r.nextInt(s.length()));
			String random=""+s1+s2+s3+s4+s5;
			
			System.out.println(random);
			int x=0;
			int x1=0;
			
			
			
			try {
				PreparedStatement ps=getConnection().prepareStatement("INSERT INTO mjnw04.uploadtable VALUES(?,?,?,?,?,?,?)");
			
				for (int i = 0; i < up.getParamValues().size(); i++)                
				    {
					ps.setString(i + 1, up.getParamValues().get(i).toString());
				    }
				ps.setString(2,up.getPublickey());
				ps.setString(3,up.getFiletype());
				ps.setString(4,up.getFilesize());
				ps.setString(5,up.getFilename());
				ps.setString(6,up.getPath());
				ps.setString(7,random.toString());
				
//				InputStream i = new FileInputStream(new File(up.getPath()));
//			ps.setBinaryStream(8, i, up.getUploadContent().available());
				 x=ps.executeUpdate();
				 
//				 
//				 PreparedStatement ps1=getConnection().prepareStatement("INSERT INTO mjnw04.copytable VALUES(?,?,?)");
//
//					for (int j = 0; j < up.getParamValues().size(); j++)                
//					    {
//						ps1.setString(j + 1, up.getParamValues().get(j).toString());
//					    }
//				ps1.setString(2, up.getFilename());
//				InputStream i1 = new FileInputStream(new File(up.getPath()));
//				ps1.setBinaryStream(3, i1,up.getUploadContent().available());
//				x1=ps1.executeUpdate();
			
				} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return x;
		}
		
		
		public ArrayList<String> getDetails()
		{
			ArrayList< String> al=new ArrayList<String>();
		
		
		try {
		PreparedStatement ps=getConnection().prepareStatement("SELECT * FROM uploadtable");
		
		ResultSet rs=ps.executeQuery();
		    while(rs.next())
		    {
		    	String owner=rs.getString(1);
		    	String filetype=rs.getString(3);
		    	String filesize=rs.getString(4);
		    	String filename=rs.getString(5);
		    	String path=rs.getString(6);
		    	String key=rs.getString(7);
		    	al.add(owner);
		    	al.add(filetype);
		    	al.add(filesize);
		    al.add(filename);
		    	al.add(path);
		    	al.add(key);
		    }
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			return al;
			
		}

	}


